from django.shortcuts import render
from Admin.models import *
from Seller.models import *
from Buyer.models import *

# Create your views here.
def index(request):
    return render(request,'index.html')

def register(request):
    countries=country_tb.objects.all()    
    return render(request,'register.html',{'countries':countries})


def registerAction(request):
    name=request.POST['name']
    gender=request.POST['gender']
    dob=request.POST['dob']
    country=request.POST['country']
    cid=country_tb.objects.get(id=country)
    state=request.POST['state']
    sid=state_tb.objects.get(id=state)
    phoneno=request.POST['phoneno']
    username=request.POST['username']
    password=request.POST['password']
    user=register_tb(name=name,gender=gender,dob=dob,country=cid,state=sid,phoneno=phoneno,emailid=username,password=password)
    user.save()
    return render(request,'register.html',{'msg':'Registration Successful'})
    

def getState(request):
    cid=request.GET.get('country_id')
    states=state_tb.objects.filter(country_id=cid)
    return render(request,'get_state.html',{'states':states})

def registerseller(request):
    countries=country_tb.objects.all()    
    return render(request,'registerseller.html',{'countries':countries})

def registerAction1(request):
    name=request.POST['name']
    gender=request.POST['gender']
    dob=request.POST['dob']
    country=request.POST['country']
    cid=country_tb.objects.get(id=country)
    state=request.POST['state']
    sid=state_tb.objects.get(id=state)
    phoneno=request.POST['phoneno']
    username=request.POST['username']
    password=request.POST['password']
    seller=register_tb1(name=name,gender=gender,dob=dob,country=cid,state=sid,phoneno=phoneno,emailid=username,password=password,status="pending")
    seller.save()
    return render(request,'registerseller.html',{'msg':'Registration Successful'})

def login(request):
    return render(request,'login.html')

def loginAction(request):
    username=request.GET.get('username')
    password=request.GET.get('password')
    user=register_tb.objects.filter(emailid=username,password=password)
    seller=register_tb1.objects.filter(emailid=username,password=password)
    admin=admin_tb.objects.filter(username=username,password=password)
    category=category_tb.objects.all()
    if(user.count()>0):
        request.session['user_id']=user[0].id
        return render(request,'buyer_home.html',{'data':user,'category':category})
    elif(seller.count()>0):
        if(seller[0].status=="Approved"):            
            request.session['seller_id']=seller[0].id
            return render(request,'seller_home.html',{'data':seller})
        else:
            if(seller[0].status=="Rejected"):
                return render(request,'login.html',{'msg':'You are Rejected'})
            else:
                return render(request,'login.html',{'msg':'Your request is still pending'})
    elif(admin.count()>0):
        request.session['admin_id']=admin[0].id
        return render(request,'admin_home.html',{'data':admin})
    else:
        return render(request,'login.html',{'msg':'Incorrect username or password'})

def logout(request):
    if('user_id' in request.session):
        del request.session['user_id']
    if('seller_id' in request.session):
        del request.session['seller_id']
    if('admin_id' in request.session):
        del request.session['admin_id']
    return render(request,'index.html')


    
def viewall_sellers(request):
    seller=register_tb1.objects.all()
    return render(request,'viewall_sellers.html',{'data':seller})

def updaterequest(request,aid):
    seller=register_tb1.objects.filter(id=aid)
    return render(request,'edit_seller.html',{'data':seller})

def updateAction(request):
    aid=request.POST['user_id']
    status=request.POST['status']
    seller=register_tb1.objects.filter(id=aid).update(status=status)
    seller=register_tb1.objects.all()
    return render(request,'viewall_sellers.html',{'data':seller,'msg':'Updated'})

def add_category(request):
    return render(request,'add_category.html')

def addCategory(request):
    categoryname=request.POST['categoryname']
    addcategory=category_tb(categoryname=categoryname)
    addcategory.save()
    return render(request,'add_category.html',{'msg':'Added'})

def forgotPassword(request):
    return render(request,'verify_email.html')

def verifyEmail(request):    
    username=request.POST['emailid']    
    buyer=register_tb.objects.filter(emailid=username)
    seller= register_tb1.objects.filter(emailid=username)
    if(buyer.count()>0):
        
        return render(request,'verify_otherdata.html',{'data':username})
    elif(seller.count()>0):
        return render(request,'verify_otherdata.html',{'data':username})
    
    else:
        return render(request,'verify_email.html',{'msg':'Invalid EmailID'})
    
def verifyOtherdata(request):
    username=request.POST['emailid']
    name=request.POST['name']
    phoneno=request.POST['phoneno']
    dob=request.POST['dob']
    buyer=register_tb.objects.filter(emailid=username,name=name,phoneno=phoneno,dob=dob)
    seller=register_tb1.objects.filter(emailid=username,name=name,phoneno=phoneno,dob=dob)
    if(buyer.count()>0):
        return render(request,'changepassword.html',{'data':username})
    elif(seller.count()>0):
        return render(request,'changepassword.html',{'data':username})
    else:
        return render(request,'verify_otherdata.html',{'data':username,'msg':'invalid data'})
    
def changepasswordAction(request):
    username=request.POST['emailid']
    password=request.POST['password']
    confirmpass=request.POST['confirmpassword']
    if(password!=confirmpass):
        return render(request,'changepassword.html',{'data':username,'msg':'Incorrect Password'})
    else:
        buyer=register_tb.objects.filter(emailid=username)    
        seller=register_tb1.objects.filter(emailid=username)
        if(buyer.count()>0):
            buyer1=register_tb.objects.filter(emailid=username).update(password=password)
            return render(request,'login.html',{'msg':'Password changed'})
        elif(seller.count()>0):
            seller1=register_tb1.objects.filter(emailid=username).update(password=password)
            return render(request,'login.html',{'msg':'Password changed'})
        else:
             return render(request,'changepassword.html',{'msg':'invalid email id or password','data':username})

def viewComplaints(request):
    cview=complaint_tb.objects.all()
    return render(request,'view_complaints.html',{'data':cview})

def returnHome(request):
    if('user_id' in request.session):
        return render(request,'buyer_home.html')
    elif('seller_id' in request.session):
        return render(request,'seller_home.html')
    elif('admin_id' in request.session) :
         return render(request,'admin_home.html')

    else:
        return render(request,'index.html')
    





























    

