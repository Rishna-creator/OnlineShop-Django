from django.db import models

# Create your models here.

class country_tb(models.Model):
    country_name=models.CharField(max_length=20)

class state_tb(models.Model):
    country_id=models.ForeignKey(country_tb,on_delete=models.CASCADE)
    state_name=models.CharField(max_length=20)
    
class register_tb(models.Model):
    name=models.CharField(max_length=20)
    gender=models.CharField(max_length=20)
    dob=models.CharField(max_length=20)
    country=models.ForeignKey(country_tb,on_delete=models.CASCADE)
    state=models.ForeignKey(state_tb,on_delete=models.CASCADE)
    phoneno=models.CharField(max_length=10)
    emailid=models.CharField(max_length=20)
    password=models.CharField(max_length=20)
    
class register_tb1(models.Model):
    name=models.CharField(max_length=20)
    gender=models.CharField(max_length=20)
    dob=models.CharField(max_length=20)
    country=models.ForeignKey(country_tb,on_delete=models.CASCADE)
    state=models.ForeignKey(state_tb,on_delete=models.CASCADE)
    phoneno=models.CharField(max_length=10)
    emailid=models.CharField(max_length=20)
    password=models.CharField(max_length=20)
    status=models.CharField(max_length=20)
    address=models.CharField(max_length=20,default='no address')

class admin_tb(models.Model):
    username=models.CharField(max_length=20)
    password=models.CharField(max_length=20)

class category_tb(models.Model):
    categoryname=models.CharField(max_length=20)

    
