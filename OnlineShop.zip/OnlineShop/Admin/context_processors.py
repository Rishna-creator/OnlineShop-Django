from Admin.models import *
from Seller.models import *
from Buyer.models import *

def getdata(request):
    categories=category_tb.objects.all()
    products=product_tb.objects.all().order_by('-id')[:8]
    
    cart=""
    count=0
    tot=0
    if('user_id' in request.session):
        cart=cart_tb.objects.filter(buyerid=request.session['user_id'])
        count=cart.count()        
        for p in cart:        
            tot=tot+p.totalprice
    return {'category':categories,'products':products,'cart':count,'tot':tot}
    
