"""OnlineShop URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url
from Admin import views as admin_view
from Buyer import views as buyer_view
from Seller import views as seller_view
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('admin/', admin.site.urls),
    url(r'^$',admin_view.index,name='index'),
    url(r'^register/',admin_view.register,name='register'),
    url(r'^registerAction/',admin_view.registerAction,name='registerAction'),
    url(r'^getState/',admin_view.getState,name='getState'),
    url(r'^registerseller/',admin_view.registerseller,name='registerseller'),
    url(r'^registerAction1',admin_view.registerAction1,name='registerAction1'),
    url(r'^login/',admin_view.login,name='login'),
    url(r'^loginAction',admin_view.loginAction,name='loginAction'),
    url(r'^viewall_sellers',admin_view.viewall_sellers,name='viewall_sellers'),
    url(r'^updaterequest/(?P<aid>\d+)/$',admin_view.updaterequest,name='updaterequest'),
    url(r'^updateAction/',admin_view.updateAction,name='updateAction'),
    url(r'^add_category/',admin_view.add_category,name='add_category'),
    url(r'^addCategory/',admin_view.addCategory,name='addCategory'),
    url(r'^add_product/',seller_view.add_product,name='add_product'),
    url(r'^addProduct/',seller_view.addProduct,name='addProduct'),
    url(r'^ViewAllProducts/',seller_view.ViewAllProducts,name='ViewAllProducts'),
    url(r'^editProduct/(?P<pid>\d+)/$',seller_view.editProduct,name='editProduct'),
    url(r'^UpdateAction/',seller_view.UpdateAction,name='UpdateAction'),
    url(r'^deleteAction/(?P<pid>\d+)/$',seller_view.deleteAction,name='deleteAction'),
    url(r'^viewProducts/',buyer_view.viewProducts,name='viewProducts'),
    url(r'^viewcart/(?P<pid>\d+)/$',buyer_view.viewcart,name='viewcart'),
    url(r'^addcartAction/',buyer_view.addcartAction,name='addcartAction'),
    url(r'^CheckCart/',buyer_view.CheckCart,name='CheckCart'),
    url(r'^confirmOrder/',buyer_view.confirmOrder,name='confirmOrder'),
    url(r'^ViewOrders/',seller_view.ViewOrders,name='ViewOrders'),
    url(r'^approveAction/(?P<aid>\d+)/$',seller_view.approveAction,name='approveAction'),
    url(r'^rejectAction/(?P<rid>\d+)/$',seller_view.rejectAction,name='rejectAction'),
    url(r'^vieworderStatus',buyer_view.vieworderStatus,name='vieworderStatus'),
    url(r'^addTrackDetails/(?P<oid>\d+)/$',seller_view.addTrackDetails,name='addTrackDetails'),
    url(r'^confirmTackDetails/',seller_view.confirmTackDetails,name='confirmTackDetails'),
    url(r'viewTrackingDetails/(?P<pid>\d+)/$',buyer_view.viewTrackingDetails,name='viewTrackingDetails'),
    url(r'^deliverdAction/(?P<did>\d+)/$',seller_view.deliverdAction,name='deliverdAction'),
    url(r'^cancelOrder/(?P<cid>\d+)/$',buyer_view.cancelOrder,name='cancelOrder'),
    url(r'^verifyCancel/(?P<pid>\d+)/$',seller_view.verifyCancel,name='verifyCancel'),
    url(r'^editProfile/',buyer_view.editProfile,name='editProfile'),
    url(r'^updateProfileBuyer/',buyer_view.updateProfileBuyer,name='updateProfileBuyer'),
    url(r'^EditSeller',seller_view.EditSeller,name='EditSeller'),
    url(r'^updateProfileSeller',seller_view.updateProfileSeller,name='updateProfileSeller'),
    url(r'^forgotPassword/',admin_view.forgotPassword,name='forgotPassword'),
    url(r'^verifyEmail',admin_view.verifyEmail,name='verifyEmail'),
    url(r'^verifyOtherdata',admin_view.verifyOtherdata,name='verifyOtherdata'),
    url(r'^changepasswordAction',admin_view.changepasswordAction,name='changepasswordAction'),
    url(r'^addReview/(?P<rid>\d+)/$',buyer_view.addReview,name='addReview'),
    url(r'^reviewAction/',buyer_view.reviewAction,name='reviewAction'),
    url(r'^viewReview/(?P<pid>\d+)/$',buyer_view.viewReview,name='viewReview'),
    url(r'^viewReview/(?P<pid>\d+)/$',seller_view.viewReview,name='viewReview'),
    url(r'^raiseComplaint',buyer_view.raiseComplaint,name='raiseComplaint'),
    url(r'^addcomplaintAction/',buyer_view.addcomplaintAction,name='addcomplaintAction'),
    url(r'^viewComplaints/',admin_view.viewComplaints,name='viewComplaints'),
    url(r'^logout/',admin_view.logout,name='logout'),
    url(r'^searchProducts/',buyer_view.searchProducts,name='searchProducts'),
    url(r'^searchwithPrice/',buyer_view.searchwithPrice,name='searchwithPrice'),
    url(r'^viewAproduct/(?P<pid>\d+)/$',buyer_view.viewAproduct,name='viewAproduct'),
    url(r'^removeCartproduct/(?P<cid>\d+)/$',buyer_view.removeCartproduct,name='removeCartproduct'),
    url(r'^returnHome/',admin_view.returnHome,name='returnHome'),
    











    
      
]
if settings.DEBUG:
    urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
