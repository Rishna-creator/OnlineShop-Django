from django.db import models
from Admin.models import *
from Seller.models import *
# Create your models here.

class cart_tb(models.Model):
    contactno=models.CharField(max_length=20)
    shipaddress=models.CharField(max_length=20)    
    totalprice=models.FloatField()
    buyerid=models.ForeignKey(register_tb,on_delete=models.CASCADE)
    sellerid=models.ForeignKey(register_tb1,on_delete=models.CASCADE)
    productid=models.ForeignKey(product_tb,on_delete=models.CASCADE)
    quantity=models.CharField(max_length=20,default='0')
    
class order_tb(models.Model):
    contactno=models.CharField(max_length=20)
    shipaddress=models.CharField(max_length=20)    
    totalprice=models.FloatField()
    buyerid=models.ForeignKey(register_tb,on_delete=models.CASCADE)
    sellerid=models.ForeignKey(register_tb1,on_delete=models.CASCADE)
    productid=models.ForeignKey(product_tb,on_delete=models.CASCADE)
    quantity=models.CharField(max_length=20,default='0')
    status=models.CharField(max_length=20)

class review_tb(models.Model):
    buyerid=models.ForeignKey(register_tb,on_delete=models.CASCADE)
    productid=models.ForeignKey(product_tb,on_delete=models.CASCADE)
    product_review=models.CharField(max_length=100)
    datetime=models.CharField(max_length=20,default='0')
    
class complaint_tb(models.Model):
    subject=models.CharField(max_length=20)
    complaint=models.CharField(max_length=100)
    buyerid=models.ForeignKey(register_tb,on_delete=models.CASCADE)
    datetime=models.CharField(max_length=20)
