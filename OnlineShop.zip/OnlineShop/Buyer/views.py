from django.shortcuts import render
from Admin.models import *
from Seller.models import *
from Buyer.models import *
import time

# Create your views here.

def viewProducts(request):
    products=product_tb.objects.all()
    return render(request,'view_products_buyer.html',{'data':products})

def viewcart(request,pid):
    product=product_tb.objects.filter(id=pid)
    
    return render(request,'view_cart.html',{'data':product})

def addcartAction(request):
    contactno=request.POST['contactno']
    shipaddress=request.POST['shipaddress']
    productid=request.POST['product_id']
    pid1=product_tb.objects.get(id=productid)
    sid=pid1.seller_id
    tot=request.POST['totalprice']
    qty=request.POST['quantity']
    
    pstock=pid1.productstock

    print('pstock',pstock)
    
    products=product_tb.objects.filter(id=productid)
    if(int(qty)>int(pstock)):
        return render(request,'view_cart.html',{'data':products,'msg':'Stock is not enogh'})
    else:
        bid=register_tb.objects.get(id=request.session['user_id'])    
        product1=cart_tb(contactno=contactno,shipaddress=shipaddress,totalprice=tot,sellerid=sid,buyerid=bid,productid=pid1,quantity=qty)
        product1.save()       
        return render(request,'view_cart.html',{'data':products,'msg':'Successful'})

def CheckCart(request):
    buyer=register_tb.objects.get(id=request.session['user_id'])
    products=cart_tb.objects.filter(buyerid=buyer)
    return render(request,'checkcart.html',{'data':products})

def confirmOrder(request):
    order=request.POST.getlist('check')
    for p in order:        
        product=cart_tb.objects.filter(id=p)              
        p1=order_tb(contactno=product[0].contactno,shipaddress=product[0].shipaddress,productid=product[0].productid,quantity=product[0].quantity,
                   totalprice=product[0].totalprice,buyerid=product[0].buyerid,sellerid=product[0].sellerid,status="pending")
        p1.save()
        pid1=product_tb.objects.get(id=product[0].productid_id)
        pstock=pid1.productstock
        totstock=int(pstock)-int(product[0].quantity)
        pid1.productstock=totstock
        pid1.save()
        product.delete()
    
    buyer=register_tb.objects.get(id=request.session['user_id'])
    products=cart_tb.objects.filter(buyerid=buyer)
    return render(request,'CheckCart.html',{'msg':'Order Confirmed','data':products})

def vieworderStatus(request):
    order=order_tb.objects.filter(buyerid=request.session['user_id'])
    return render(request,'order_status.html',{'data':order})

def viewTrackingDetails(request,pid):
    details=track_tb.objects.filter(orderid=pid)
    return render(request,'view_buyer_trackdetails.html',{'data':details})

def cancelOrder(request,cid):
    cancel_products=order_tb.objects.filter(id=cid).update(status="cancel")
    details=order_tb.objects.filter(buyerid=request.session['user_id'])         
    
    
    return render(request,'order_status.html',{'data':details,'msg':'Updated'})

def editProfile(request):
    buyer=register_tb.objects.filter(id=request.session['user_id'])
    countries=country_tb.objects.all()  
    return render(request,'edit_profile_buyer.html',{'data':buyer,'countries':countries})

def updateProfileBuyer(request):
    bid=request.POST['user_id']
    name=request.POST['name']
    gender=request.POST['gender']
    dob=request.POST['dob']
    country=request.POST['country']
    cid=country_tb.objects.get(id=country)
    state=request.POST['state']
    sid=state_tb.objects.get(id=state)
    phoneno=request.POST['phoneno']
    username=request.POST['username']
    password=request.POST['password']
    user=register_tb.objects.filter(id=bid).update(name=name,gender=gender,dob=dob,country=cid,state=sid,phoneno=phoneno,emailid=username,password=password)
    countries=country_tb.objects.all()
    buyer=register_tb.objects.filter(id=request.session['user_id'])
    return render(request,'edit_profile_buyer.html',{'countries':countries,'data':buyer,'msg':'Updation Successful'})

def addReview(request,rid):
    products=order_tb.objects.filter(id=rid)
    return render(request,'add_review.html',{'data':products})

def reviewAction(request):     
    product_id=request.POST['product_id']
    pid1=product_tb.objects.get(id=product_id)
    buyer=register_tb.objects.get(id=request.session['user_id'])
    preview=request.POST['review']
    reviewdetails=review_tb(buyerid=buyer,productid=pid1,product_review=preview,datetime=time.asctime(time.localtime(time.time())))
    reviewdetails.save()
    order=order_tb.objects.filter(buyerid=request.session['user_id'])
    return render(request,'order_status.html',{'data':order,'msg':'Review Added'})

def viewReview(request,pid):    
    preview=review_tb.objects.filter(productid=pid)
    return render(request,'view_review.html',{'data':preview})
    
 
def raiseComplaint(request):
    return render(request,'add_complaints.html')

def addcomplaintAction(request):    
    buyer=register_tb.objects.get(id=request.session['user_id'])
    sub=request.POST['sub']
    complaint=request.POST['complaint']
    details=complaint_tb(buyerid=buyer,subject=sub,complaint=complaint,datetime=time.asctime(time.localtime(time.time())))
    details.save()
    com=complaint_tb.objects.all()
    return render(request,'add_complaints.html',{'data':com,'msg':'complaint added successfully'})

def searchProducts(request):    
    product=request.POST['searchproduct']
    pcategory=request.POST['category']
    ptable=product_tb.objects.filter(productcategory=pcategory,productname__contains=product)
    return render(request,'view_products_buyer.html',{'data':ptable})

def searchwithPrice(request):
    pcategory=request.POST['category']
    price=float(request.POST['price'])
    ptable=product_tb.objects.filter(productcategory=pcategory,productprice__lte=price)
    return render(request,'view_products_buyer.html',{'data':ptable})
    
def viewAproduct(request,pid):
    viewproduct=product_tb.objects.filter(id=pid)
    return render(request,'view_a_product.html',{'viewproduct':viewproduct})

def removeCartproduct(request,cid):
    product=cart_tb.objects.filter(id=cid)
    product.delete()
    carts=cart_tb.objects.filter(buyerid=request.session['user_id'])
    return render(request,'checkcart.html',{'data':carts})
    


    
    













