from django.shortcuts import render
from Admin.models import *
from Seller.models import *
from Buyer.models import *
import time 
# Create your views here.
def add_product(request):
    data=category_tb.objects.all()
    return render(request,'add_product.html',{'data':data})

def addProduct(request):
    productname=request.POST['productname']
    cid1=request.POST['productcategory']
    cid=category_tb.objects.get(id=cid1)
    productdetails=request.POST['productdetails']
    productstock=request.POST['productstock']
    productprice=request.POST['productprice']
    sid=register_tb1.objects.get(id=request.session['seller_id'])
    mypic=""
    if(len(request.FILES)>0):
        mypic=request.FILES['fileupload']
    else:
        mypic="no pic"
    product=product_tb(productname=productname,productdetails=productdetails,productstock=productstock,productprice=productprice,file=mypic,
                       productcategory=cid,seller_id=sid)
    product.save()
    allproducts=product_tb.objects.all()
    return render(request,'view_products.html',{'msg':'Product Added Successfuly','data':allproducts})

def ViewAllProducts(request):
    allproducts=product_tb.objects.filter(seller_id=request.session['seller_id'])
    return render(request,'view_products.html',{'data':allproducts})


def editProduct(request,pid):
    products=product_tb.objects.filter(id=pid)
    data1=category_tb.objects.all()
    return render(request,'edit_products.html',{'data':products,'data1':data1})

def UpdateAction(request):
    pid=request.POST['product_id']    
    productname=request.POST['productname']
    productcategory=request.POST['category']
    productdetails=request.POST['productdetails']
    productstock=request.POST['productstock']
    productprice=request.POST['productprice']
    mypic=""
    products=product_tb.objects.get(id=pid)
    if(len(request.FILES)>0):
        mypic=request.FILES['fileupload']
    else:
        mypic=products.file
    
    products.productname=productname
    cid=category_tb.objects.get(id=productcategory)
    products.productcategory=cid
    products.productdetails=productdetails
    products.productstock=productstock
    products.productprice=productprice
    products.file=mypic
    products.save()
    products=product_tb.objects.all()
    return render(request,'view_products.html',{'data':products,'msg':'Updated'})
                                                         
def deleteAction(request,pid):
    products=product_tb.objects.filter(id=pid).delete()
    product=product_tb.objects.all()
    return render(request,'view_products.html',{'data':product,'msg':'Deleted'})

def ViewOrders(request):   
    orders=order_tb.objects.filter(sellerid=request.session['seller_id']).exclude(status='reject')    
    return render(request,'seller_order_view.html',{'data':orders})



def approveAction(request,aid):   
    approve_products=order_tb.objects.filter(id=aid).update(status="approved")
    approve_products=order_tb.objects.filter(sellerid=request.session['seller_id']).exclude(status='reject')
    return render(request,'seller_order_view.html',{'data':approve_products,'msg':'Updated'})
    
def rejectAction(request,rid):
    reject_products=order_tb.objects.filter(id=rid).update(status="reject")
    order=order_tb.objects.filter(id=rid)
    qnty=order[0].quantity
    product=product_tb.objects.filter(id=order[0].productid_id)
    pstock=product[0].productstock
    pstock1=int(pstock)+int(qnty)    
    product.update(productstock=pstock1)
    reject_products=order_tb.objects.filter(sellerid=request.session['seller_id']).exclude(status='reject')
    return render(request,'seller_order_view.html',{'data':reject_products,'msg':'Updated'})

def addTrackDetails(request,oid):
    orders=order_tb.objects.filter(id=oid)    
    return render(request,'add_track_details.html',{'data':orders})

def confirmTackDetails(request):
    orderid=request.POST['orderid']
    oid1=order_tb.objects.get(id=orderid)    
    trackdetails=request.POST['trackdetails']

       
    details=track_tb(trackdetails=trackdetails,orderid=oid1,datetime=time.asctime(time.localtime(time.time())))
    
    details.save()
    approve_products=order_tb.objects.filter(sellerid=request.session['seller_id']).exclude(status='reject')
    return render(request,'seller_order_view.html',{'data':approve_products,'msg':'Added Successfully'})

def deliverdAction(request,did):
    deliverd_products=order_tb.objects.filter(id=did).update(status="deliverd")
    oid1=order_tb.objects.get(id=did)     
    details=track_tb(trackdetails='deliverd',orderid=oid1,datetime=time.asctime(time.localtime(time.time())))
    details.save()
    deliverd_products=order_tb.objects.filter(sellerid=request.session['seller_id']).exclude(status='reject' )
    return render(request,'seller_order_view.html',{'data':deliverd_products,'msg':'Updated'})
     
def verifyCancel(request,pid):
    verify_cancel=order_tb.objects.filter(id=pid).update(status="verified cancel")
    order=order_tb.objects.filter(id=pid)
    qnty=order[0].quantity
    product=product_tb.objects.filter(id=order[0].productid_id)
    pstock=product[0].productstock
    pstock1=int(pstock)+int(qnty)    
    product.update(productstock=pstock1)
    verify_cancel=order_tb.objects.filter(sellerid=request.session['seller_id']).exclude(status='reject')   
    return render(request,'seller_order_view.html',{'data':verify_cancel,'msg':'verified cancel'})

def EditSeller(request):
    seller=register_tb1.objects.filter(id=request.session['seller_id'])
    countries=country_tb.objects.all()
    return render(request,'update_seller_profile.html',{'data':seller,'countries':countries})

def updateProfileSeller(request):
    sid=request.POST['user_id']
    name=request.POST['name']
    gender=request.POST['gender']
    dob=request.POST['dob']
    country=request.POST['country']
    cid=country_tb.objects.get(id=country)
    state=request.POST['state']
    sid1=state_tb.objects.get(id=state)
    phoneno=request.POST['phoneno']
    username=request.POST['username']
    password=request.POST['password']
    seller1=register_tb1.objects.filter(id=sid).update(name=name,gender=gender,dob=dob,country=cid,state=sid1,phoneno=phoneno,emailid=username,password=password)
    seller=register_tb1.objects.filter(id=request.session['seller_id'])
    return render(request,'update_seller_profile.html',{'data':seller,'msg':'Updation Successful'})

def viewReview(request,pid):    
    preview=review_tb.objects.filter(productid=pid)
    return render(request,'view_review.html',{'data':preview})
    














    
