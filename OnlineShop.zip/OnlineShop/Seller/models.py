from django.db import models
from Admin.models import *
from Buyer.models import *
# Create your models here.

class product_tb(models.Model):
    productname=models.CharField(max_length=20)
    productcategory=models.ForeignKey(category_tb,on_delete=models.CASCADE)
    productdetails=models.CharField(max_length=100)
    productstock=models.CharField(max_length=20)
    productprice=models.FloatField(max_length=20)
    file=models.FileField()
    seller_id=models.ForeignKey(register_tb1,on_delete=models.CASCADE)

class track_tb(models.Model):
    orderid=models.ForeignKey('Buyer.order_tb',on_delete=models.CASCADE)
    trackdetails=models.CharField(max_length=200)
    datetime=models.CharField(max_length=20)
    
    
